create database zomato_db;
use zomato_db;

select * from zomato;

-- View First 10 Rows
SELECT * from zomato limit 10;

--  Count Total Restaurants
SELECT COUNT(*) AS total_restaurants FROM zomato;

--  List All Unique Cities
SELECT DISTINCT city FROM zomato;

-- Top 10 Cities with Most Restaurants
SELECT city, count(*) AS total
from zomato
group by city
order by total desc
limit 10;

--  Average Rating by City
SELECT city, ROUND(AVG(Avg_Rating_City), 2) AS avg_rating
FROM zomato
GROUP BY city
ORDER BY avg_rating DESC;

-- Top 10 Most Voted Restaurants
SELECT restaurant_name, city, votes
FROM zomato
ORDER BY votes DESC
LIMIT 10;

-- Cost & Delivery-Based Insights
--  Most Expensive Restaurants
SELECT restaurant_name, city, Avg_Price_City
FROM zomato
ORDER BY Avg_Price_City DESC
LIMIT 10;

--   Delivery Availability (Count)
SELECT Delivery_Votes, COUNT(*) AS count
FROM zomato
GROUP BY Delivery_Votes;

-- Most Popular Cuisines
SELECT cuisine, COUNT(*) AS count
FROM zomato
GROUP BY cuisine
ORDER BY count DESC
LIMIT 10;

--  Best Rated Restaurants (Above 4.5)
SELECT restaurant_name, city, Avg_Rating_Restaurant
FROM zomato
WHERE Avg_Rating_Restaurant >= 3.5
ORDER BY Avg_Rating_Restaurant DESC;

-- CASE WHEN: Delivery Status
SELECT restaurant_name, city,
    CASE 
        WHEN Votes = 'Yes' THEN 'Delivery Available'
        ELSE 'No Delivery'
    END AS delivery_status
FROM zomato;

--  Subquery: Restaurants with Above-Average Ratings
SELECT restaurant_name, Average_Rating
FROM zomato
WHERE Average_Rating > (
    SELECT AVG(Average_Rating) FROM zomato
);

--  Create View: High-Rated Restaurants
SELECT restaurant_name, city, Average_Rating
FROM zomato
WHERE Average_Rating >= 3.5;







